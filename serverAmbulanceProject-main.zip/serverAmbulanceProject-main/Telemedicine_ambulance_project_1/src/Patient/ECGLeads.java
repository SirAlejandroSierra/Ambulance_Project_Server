/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Patient;

/**
 *
 * @author hecye
 */
public enum ECGLeads {
    LEAD_I, LEAD_II, LEAD_III, aVR, aVL, aVF;
}
